import 'package:flutter/material.dart';
import '../jogos_page.dart';

void main() {
  runApp(
    MaterialApp(
      home: JogosPage(),
    ),
  );
}
