class CartaoResumo {
  final String image;
  final String titulo;
  final String descricao;

  CartaoResumo({required this.image, required this.titulo, required this.descricao});
}
