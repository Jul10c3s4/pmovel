class Atributos {
  final String titulo;
  final String descricao;

  Atributos({
    required this.titulo,
    required this.descricao,
  });
}
