class ConteudosDeMatematica {
  final String video;
  final String conceito;
  final String questao;

  ConteudosDeMatematica({
    required this.video,
    required this.conceito,
    required this.questao,
  });
}
