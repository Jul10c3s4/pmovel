package com.example.telasjogos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
